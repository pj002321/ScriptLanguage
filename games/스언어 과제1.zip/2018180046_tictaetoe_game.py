from tkinter import *
import random


def Button_Set(tk):
    c=Button(tk,width=100,height=100,bd=10,image=imgbt)
    return c


def Reset():
    global OX
    for i in range(3):
        for j in range(3):
                c[i][j]["state"]=NORMAL
                c[i][j]["text"]=NORMAL
    OX=random.choice(['o','x'])  
    
        
def Check_Token():
    from tkinter import messagebox
    # 무승부
    if(c[0][0]["state"]==c[0][1]["state"]==c[0][2]["state"] 
        ==c[1][0]["state"]==c[1][1]["state"]==c[1][2]["state"] \
        ==c[2][0]["state"]==c[2][1]["state"]==c[2][2]["state"]==DISABLED):
                messagebox.showinfo("GameOver","compare")
                Reset()
    
    for i in range(3):
            # 평행
            if(c[i][0]["text"]==c[i][1]["text"]==c[i][2]["text"]==OX or c[0][i]["text"]==c[1][i]["text"]==c[2][i]["text"]==OX):
                    messagebox.showinfo("GameOver",OX+" -> Win!")
                    Reset()
            
    # 대각선
    if(c[0][0]["text"]==c[1][1]["text"]==c[2][2]["text"]==OX or c[0][2]["text"]==c[1][1]["text"]==c[2][0]["text"]==OX):
            messagebox.showinfo("GameOver",OX+" ->Win!")
            Reset()   
    

def Change_Turn():
    global OX
    for i in ['o','x']:
        if not(i==OX):
            OX,i=i,OX
            break

def Click_Button(row,col):
        c[row][col].config(text=OX,state=DISABLED,image=colour[OX])
        Check_Token()
        Change_Turn()
        label.config(text=OX+"Turn")



root=Tk()
root.geometry("360x400")
root.title("2018180046 허재성 Tic-Tac-Toe 게임")
label=  Label(text="Tic-Tac-Toe game",font=('Helvetica',15,'bold'))
label.grid(row=4,columnspan=4)
imgo =  PhotoImage(file = "o.gif")
imgx =  PhotoImage(file = "x.gif")
imgbt=  PhotoImage(file = "empty.gif")
OX   =  random.choice(['o','x'])  
colour= {'o':imgo,'x':imgx}

c=[[],[],[]]
for i in range(3):
        for j in range(3):
                c[i].append(Button_Set(root))
                c[i][j].config(command= lambda row=i,col=j:Click_Button(row,col))
                c[i][j].grid(row=i,column=j)



root.mainloop()