from tkinter import * 
import random



infile = open("hangman.txt", "r")
words = infile.read().split()

class Hangman:

        
    def drawhangman(self):
        canvas.delete("hangman")
        canvas.create_arc(20, 200, 100, 240, start = 0, extent = 180) 
        canvas.create_line(60, 200, 60, 20, tags = "hangman") 
        canvas.create_line(60, 20, 160, 20, tags = "hangman") 

        if self.nMisschar > 0:
            canvas.create_line(160, 20, 160, 40, tags = "hangman") 
            canvas.create_oval(140, 40, 180, 80, tags = "hangman") 

        if self.nMisschar > 1:
            canvas.create_line(150, 77, 100, 120, tags = "hangman")

        if self.nMisschar > 2:
            canvas.create_line(170, 77, 220, 120, tags="hangman")

        if self.nMisschar > 3:
            canvas.create_oval(160, 80, 160, 140, tags="hangman")

        if self.nMisschar > 4:
            canvas.create_line(160, 140, 110, 190, tags="hangman")

        if self.nMisschar > 5:
            canvas.create_line(160, 140, 210, 190, tags="hangman")

        if self.finished == 1:
            canvas.delete("text")
            answer = "정답! " + ''.join(self.hiddenWord) + "입니다."
            canvas.create_text(200, 220, text=answer, tags="text")
            canvas.create_text(200, 250, text="ENTER를 누르면 새로 시작됩니다.", tags="text")

        if self.finished == 2:
            canvas.delete("text")
            answer = "정답은 " + ''.join(self.hiddenWord) + "입니다."
            canvas.create_text(200, 220, text=answer, tags="text")
            canvas.create_text(200, 250, text="틀렸습니다. ENTER를 누르면 새로 시작됩니다.", tags="text")

        WrongCnt = "잘못입력한 수: " + str(self.nMisschar)
        canvas.create_text(100,300,text = WrongCnt,tags="text")
        CorrectCnt = "맞춘 글자 수: " + str(self.nCorrectchar)
        canvas.create_text(100, 320, text=CorrectCnt, tags="text")

    def guess(self, letter):
        if self.finished == 0:
            if letter not in self.guessWord:
                for c in range(0, len(self.hiddenWord)):
                    if self.hiddenWord[c] == letter:
                        self.guessWord[c] = letter
                        self.nCorrectchar += 1

                if letter not in self.hiddenWord:
                    if letter not in self.nMissLetters:
                        self.nMisschar += 1
                        self.nMissLetters.append(letter)
                        
            if self.hiddenWord == ''.join(self.guessWord):
                self.finished = 1

            if self.nMisschar > 6:
                self.finished = 2


        canvas.delete("text")

        hdword = "단어추측: " + ''.join(self.guessWord)
        hwd = canvas.create_text(200, 200, text=hdword, tags="text")
        WrongWord = "틀린 글자: " + ','.join(self.nMissLetters)

        canvas.create_text(300, 300, text=WrongWord, tags="text")

        self.drawhangman()



    def setWord(self):

        canvas.delete("text")
        self.drawhangman()
        self.hiddenWord = random.choice(words)
        self.guessWord = ["*" for i in range(len(self.hiddenWord))]
        self.nCorrectchar = 0
        self.nMisschar = 0
        self.finished = 0
        self.nMissLetters = []
        
    def __init__(self):
        self.hiddenWord = random.choice(words)  
        self.guessWord = ["*" for i in range(len(self.hiddenWord))]  
        self.nCorrectchar = 0  
        self.nMisschar = 0  
        self.nMissLetters = []    
        self.finished = 0   
        self.drawhangman()

def KeyEvent(event):  
    global main
    key = event.keysym

    if 'a' <= event.char and event.char <= 'z':
        main.guess(key)

    elif event.keycode == 13:
        main.setWord()

window = Tk()
window.title("행맨")
canvas = Canvas(window, bg="white", width=420, height=380)
canvas.pack()

canvas.focus_set()
canvas.bind("<Key>", KeyEvent)
main = Hangman()
window.mainloop() 